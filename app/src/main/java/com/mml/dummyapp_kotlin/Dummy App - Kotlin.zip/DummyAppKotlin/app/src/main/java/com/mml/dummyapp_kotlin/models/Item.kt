package com.mml.dummyapp_kotlin.models


import android.os.Parcelable
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
@JsonClass(generateAdapter = true)
data class Item(
    @Json(name = "author")
    val author: @RawValue Author,
    @Json(name = "blog")
    val blog: @RawValue Blog,
    @Json(name = "content")
    val content: String,
    @Json(name = "etag")
    val etag: String,
    @Json(name = "id")
    val id: String,
    @Json(name = "kind")
    val kind: String,
    @Json(name = "labels")
    val labels: List<String>,
    @Json(name = "published")
    val published: String,
    @Json(name = "replies")
    val replies: @RawValue Replies,
    @Json(name = "selfLink")
    val selfLink: String,
    @Json(name = "title")
    val title: String,
    @Json(name = "updated")
    val updated: String,
    @Json(name = "url")
    val url: String
) : Parcelable