package com.mml.dummyapp_kotlin.models


import android.os.Parcelable
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
@JsonClass(generateAdapter = true)
data class Author(
    @Json(name = "displayName")
    val displayName: String,
    @Json(name = "id")
    val id: String,
    @Json(name = "image")
    val image: @RawValue Image,
    @Json(name = "url")
    val url: String
) : Parcelable