package com.mml.dummyapp_kotlin.viewmodels

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.mml.dummyapp_kotlin.data.Repository
import com.mml.dummyapp_kotlin.models.Item
import com.mml.dummyapp_kotlin.models.PostList
import com.mml.dummyapp_kotlin.util.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PostViewModel"

@HiltViewModel
class PostViewModel @Inject constructor(
    private val repository: Repository,
    application: Application
) :
    AndroidViewModel(application) {
    val postListMutableLiveData: MutableLiveData<PostList?> = MutableLiveData<PostList?>()
    var postsResponse: MutableLiveData<NetworkResult<PostList>> = MutableLiveData()
    val finalURL = MutableLiveData<String>()
    private val token = MutableLiveData<String>()
    val label = MutableLiveData<String>()
    val errorCode = MutableLiveData<Int>()
    val searchError = MutableLiveData<Boolean>()
    val getItemsBySearchMT: MutableLiveData<List<Item>> = MutableLiveData<List<Item>>()
    private val isLoading = MutableLiveData<Boolean>()
    val recyclerViewLayoutMT = MutableLiveData<String>()
    val currentDestination = MutableLiveData<Int>()


    //    @Override
    //    protected void onCleared() {
    //        super.onCleared();
    //        postListMutableLiveData.setValue(null);
    //        finalURL.setValue(null);
    //        token.setValue(null);
    //    }



    fun getPosts() = viewModelScope.launch {
        getPostsSafeCall()
    }

    private suspend fun getPostsSafeCall() {
        postsResponse.value = NetworkResult.Loading()
        if (hasInternetConnection()) {
            try {
                val response = repository.remote.getPostList(finalURL.value)
                postsResponse.value = handlePostsResponse(response)

                val postList = postsResponse.value!!.data
                if(postList != null) {
//                    offlineCacheRecipes(foodRecipe)
                    Log.e(TAG, "getPostsSafeCall: postList is null" )
                }
            } catch (e: Exception) {
                postsResponse.value = NetworkResult.Error("Recipes not found.")
            }
        } else {
            postsResponse.value = NetworkResult.Error("No Internet Connection.")
        }
    }



    private fun handlePostsResponse(response: Response<PostList?>?): NetworkResult<PostList> {
        when {
            response?.message().toString().contains("timeout") -> {
                return NetworkResult.Error("Timeout")
            }
            response?.code() == 402 -> {
                return NetworkResult.Error("API Key Limited.")
            }
            response?.body()!!.items.isNullOrEmpty() -> {
                return NetworkResult.Error("Recipes not found.")
            }
            response.isSuccessful -> {
                val postListResponse = response.body()
                if (postListResponse?.nextPageToken != null
                ) {
                    Log.e(TAG, postListResponse.nextPageToken)
                    token.value = postListResponse.nextPageToken
                    isLoading.value = false
                }
                postListMutableLiveData.setValue(postListResponse)
                return NetworkResult.Success(postListResponse!!)
            }
            else -> {
                return NetworkResult.Error(response.message())
            }
        }
    }

//    val posts: Unit
//        get() {
//            Log.e(TAG, finalURL.value!!)
//            isLoading.value = true
//            repository.remote.getPostList(finalURL.value)
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(object : Observer<Response<PostList?>> {
//                    override fun onSubscribe(d: Disposable) {}
//                    override fun onNext(postListResponse: Response<PostList?>) {
//                        if (postListResponse.isSuccessful) {
//                            if (postListResponse.body() != null
//                                && postListResponse.body().nextPageToken != null
//                            ) {
//                                Log.e(TAG, postListResponse.body().getNextPageToken())
//                                token.value = postListResponse.body().getNextPageToken()
//                                isLoading.value = false
//                            }
//                            postListMutableLiveData.setValue(postListResponse.body())
//
//                            for (i in 0 until postListResponse.body().getItems().size()) {
//                                repository.localDataSource.insertItem(
//                                    postListResponse.body()
//                                        .getItems().get(i)
//                                )
//                                    .subscribeOn(Schedulers.io())
//                                    .observeOn(AndroidSchedulers.mainThread())
//                                    .subscribe(object : CompletableObserver {
//                                        override fun onSubscribe(d: Disposable) {}
//                                        override fun onComplete() {}
//                                        override fun onError(e: Throwable) {}
//                                    })
//                            }
//                            finalURL.setValue(finalURL.value.toString() + "&pageToken=" + token.value)
//                        } else {
//                            isLoading.setValue(false)
//                            errorCode.setValue(postListResponse.code())
//                            Log.e(TAG, "onNext: " + postListResponse.code())
//                            Log.e(TAG, "onNext: " + postListResponse.errorBody())
//                        }
//                    }
//
//                    override fun onError(e: Throwable) {
//                        isLoading.setValue(false)
//                        Log.e(TAG, e.message + e.cause)
//                        if (e is HttpException) {
//                            errorCode.setValue(e.code())
//                        }
//                    }
//
//                    override fun onComplete() {}
//                })
//        }
//


    private fun hasInternetConnection(): Boolean {

        val connectivityManager = getApplication<Application>().getSystemService(
            Context.CONNECTIVITY_SERVICE
        ) as ConnectivityManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val activeNetwork = connectivityManager.activeNetwork ?: return false
            val capabilities =
                connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
            return when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> true
                else -> false
            }
        } else {
            val networkInfo = connectivityManager.activeNetworkInfo
            return networkInfo != null && networkInfo.isConnectedOrConnecting
        }

    }

}