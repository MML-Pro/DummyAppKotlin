package com.mml.dummyapp_kotlin.ui.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.mml.dummyapp_kotlin.adapters.PostAdapter
import com.mml.dummyapp_kotlin.adapters.PostAdapter.Companion.TAG
import com.mml.dummyapp_kotlin.databinding.FragmentHomeBinding
import com.mml.dummyapp_kotlin.models.Item
import com.mml.dummyapp_kotlin.util.Constatns
import com.mml.dummyapp_kotlin.util.NetworkResult
import com.mml.dummyapp_kotlin.util.WrapContentLinearLayoutManager
import com.mml.dummyapp_kotlin.viewmodels.PostViewModel
import dagger.hilt.EntryPoint
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "HomeFragment"

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private var itemArrayList: List<Item>? = null

    private lateinit var postViewModel: PostViewModel
    private val titleLayoutManager: GridLayoutManager? = null
    private  var gridLayoutManager:GridLayoutManager? = null
    var layoutManager: WrapContentLinearLayoutManager? = null

    private val mAdapter by lazy {
        context?.let { PostAdapter(it, itemArrayList!!,this,postViewModel) }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        itemArrayList = ArrayList()
        postViewModel = ViewModelProvider(this)[PostViewModel::class.java]
        postViewModel.finalURL.setValue(
            Constatns.BASE_URL + "?key=" + Constatns.API_KEY
        )
    }


    // This property is only valid between onCreateView and
    // onDestroyView.

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        postViewModel.recyclerViewLayoutMT.observe(viewLifecycleOwner) { layout ->
            Log.w(TAG, "getSavedLayout: called")
            when (layout) {
                "cardLayout" -> {
                    binding.loadMoreBtn.visibility = View.VISIBLE
                    binding.homeRecyclerView.layoutManager = layoutManager
                    binding.homeRecyclerView.adapter = mAdapter
                    mAdapter?.setViewType(0)
                }
                "cardMagazineLayout" -> {
                    binding.loadMoreBtn.visibility = View.VISIBLE
                    binding.homeRecyclerView.layoutManager = layoutManager
                    binding.homeRecyclerView.adapter = mAdapter
                    mAdapter?.setViewType(1)
                }
                "titleLayout" -> {
                    binding.loadMoreBtn.visibility = View.GONE
                    binding.homeRecyclerView.layoutManager = titleLayoutManager
                    binding.homeRecyclerView.adapter = mAdapter
                    mAdapter?.setViewType(2)
                }
                "gridLayout" -> {
                    binding.loadMoreBtn.visibility = View.GONE
                    binding.homeRecyclerView.layoutManager = gridLayoutManager
                    binding.homeRecyclerView.adapter = mAdapter
                    mAdapter?.setViewType(3)
                }
            }
        }

        requestApiData()

        return binding.root
    }

    private fun requestApiData() {
        Log.d(TAG, "requestApiData: called")
        postViewModel.getPosts()
        postViewModel.postsResponse.observe(viewLifecycleOwner) { response ->

            when (response) {
                is NetworkResult.Success -> {
                    hideShimmerEffect()
                    response.data?.let {
                        itemArrayList = it.items
                    }
                }

                is NetworkResult.Error -> {
                    hideShimmerEffect()
    //                    loadDataFromCache()
                    Toast.makeText(
                        requireContext(),
                        response.message.toString(),
                        Toast.LENGTH_LONG
                    ).show()
                    Log.e(TAG, response.data.toString())
                    Log.e(TAG, response.message.toString())
                }

                is NetworkResult.Loading -> {
                    showShimmerEffect()
                }
            }

        }

    }


    private fun showShimmerEffect() {


//        binding.homeRecyclerView.setAdapter(adapter);
        binding.shimmerLayout.visibility = View.VISIBLE
        binding.homeRecyclerView.visibility = View.INVISIBLE
    }

    private fun hideShimmerEffect() {
        _binding?.shimmerLayout?.stopShimmer()
        _binding?.shimmerLayout?.visibility  = View.GONE
        _binding?.homeRecyclerView?.visibility = View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}